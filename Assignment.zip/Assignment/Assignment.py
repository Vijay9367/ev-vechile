from fastapi import FastAPI, Request 
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from google.auth.transport import requests
import google.oauth2.id_token;
from google.cloud import firestore
import starlette.status as status
from google.cloud.firestore_v1.base_query import FieldFilter
from fastapi.params import Query
from datetime import datetime


app = FastAPI()

firestore_db = firestore.Client()

firebase_request_adapter = requests.Request()

app.mount('/static', StaticFiles(directory='static'), name='static')
templates = Jinja2Templates(directory="templates")

def getUser(user_token):

    user1 = firestore_db.collection('users').document(user_token['user_id'])
    
    if not user1.get().exists:
        user_data = {
            'name': 'No name yet',
            'age': 0,
        }
        firestore_db.collection('users').document(user_token['user_id']).set(user_data)
    return user1
def getDocID( data):
    query = firestore_db.collection('evlist').where('Name', '==', data).stream()
    for doc in query:
        docID = doc.id
    return docID
    

def validateFirebaseToken(id_token):
    if not id_token:
        return None
    user_token = None
    try:
        user_token = google.oauth2.id_token.verify_firebase_token(id_token, firebase_request_adapter)
    except ValueError as err:

        print(str(err))

    return user_token

@app.get("/", response_class=HTMLResponse)
async def root (request: Request):
    id_token = request.cookies.get("token")
    error_message = "No error here"
    user_token = None
    user = None
    collection_ref1=None
    all_documents = []
    user_token = validateFirebaseToken(id_token)
    collection_ref1 = firestore_db.collection('evlist').get()

    if not user_token:
        return templates.TemplateResponse('main.html', {'request': request, 'user_token': None, 'error_message': None, 'user_info':None,'Ev_info':collection_ref1})
    user = getUser(user_token)
    return templates.TemplateResponse('main.html', {'request': request, 'user_token': user_token, 'error_message': error_message, 'user_info': user.get(),'Ev_info':collection_ref1})
@app.get("/Add-Ev",response_class=HTMLResponse)
async def AddEV(request: Request):
    collection_ref1 = firestore_db.collection('evlist').get()
    return templates.TemplateResponse('Add.html', {'request': request,'Ev_info':collection_ref1})
@app.post("/Add-data", response_class=RedirectResponse)
async def adddata(request: Request):
    id_token = request.cookies.get("token")
    user_token = validateFirebaseToken(id_token)
    if not user_token:
        return RedirectResponse('/')
    
    form = await request.form()
    existing_ev = firestore_db.collection('evlist').where('Name', '==', form['Name']).get()
    if existing_ev:
        return RedirectResponse('/', status_code=status.HTTP_302_FOUND)
    address_ref = firestore_db.collection('evlist').document()

    address_ref.set({
        'Name': form['Name'],
        'Manufacturer': form['Manufacturere'],
        'Year': form['Year'],
        'Battery':form['Battery Size(Kwh)'],
        'WLTP':form['WLTP'],
        'cost':form['cost'],
        'Power':form['power']

    })
    
    return RedirectResponse('/', status_code=status.HTTP_302_FOUND)
@app.get("/Search-data",response_class=HTMLResponse)
async def searchEV(request: Request):
    collection_ref1 = firestore_db.collection('evlist').get()
    return templates.TemplateResponse('search.html', {'request': request,'Ev_info':collection_ref1})

@app.get("/Search-result", response_class=HTMLResponse)
async def search_query(request: Request, attribute: str = None, value: str = None, lower_limit: str = None, upper_limit: str = None):
    collection_ref1 = firestore_db.collection('evlist')
    query = collection_ref1
    collection_ref2 = firestore_db.collection('evlist').get()

    if attribute or (value is None or value == "") or (lower_limit is not None and upper_limit is not None):
        if attribute in ["Name", "Manufacturer"]:  
            query = query.where(attribute, "==", value)
        elif attribute in ["Year", "Battery", "WLTP", "cost", "power"]:  
            if  value is None or value == "":
                query = query.where(attribute, ">=", lower_limit).where(attribute, "<=", upper_limit)
            else:  
                query = query.where(attribute, "==", value)            
    results = query.stream()
    filtered_evs = [doc.to_dict() for doc in results]
    if not filtered_evs:
        return templates.TemplateResponse('search.html', {'request': request,'Ev_info':collection_ref2})
    else:
        return templates.TemplateResponse("search_results.html", {"request": request, "filtered_evs": filtered_evs})
@app.get("/ev-info/{ev_id}", response_class=HTMLResponse)
async def ev_info(request: Request, ev_id: str):
    id_token = request.cookies.get("token")
    user_token = validateFirebaseToken(id_token)
    if not user_token:
        return RedirectResponse('/')
    docId=getDocID(ev_id)
    collection_ref = firestore_db.collection('evlist')
    doc_ref = collection_ref.document(docId)
    ev_data = doc_ref.get()
    user = getUser(user_token)
    return templates.TemplateResponse("Info.html", {"request": request, "Ev_info": ev_data ,"user_token": user_token,'user_info': user.get()})
@app.get("/Compare-data",response_class=HTMLResponse)
async def Compare_ev(request: Request):
    collection_ref1 = firestore_db.collection('evlist').get()
    return templates.TemplateResponse('compare.html', {'request': request,'Ev_info': collection_ref1})
@app.post("/compare-evs", response_class=RedirectResponse)
async def compare_evs(request: Request):
    form = await request.form()
    ev1_name = form.get("Name1")
    ev2_name = form.get("Name2")
    return RedirectResponse(f"/comparison/{ev1_name}/{ev2_name}")
@app.post("/comparison/{ev1_name}/{ev2_name}", response_class=HTMLResponse)
async def show_comparison(request: Request, ev1_name: str, ev2_name: str):
    docId1=getDocID(ev1_name)
    docId2=getDocID(ev2_name)
    collection_ref = firestore_db.collection('evlist')
    ev1_data = collection_ref.document(docId1).get()
    ev2_data = collection_ref.document(docId2).get()
    ev1_ref = firestore_db.collection('ev_reviews').document(docId1).collection('reviews')
    ev2_ref = firestore_db.collection('ev_reviews').document(docId2).collection('reviews')
    ev1_reviews_snapshot = ev1_ref.stream()
    ev2_reviews_snapshot = ev2_ref.stream()
    ev1_total_ratings = 0
    ev1_num_reviews = 0
    for review in ev1_reviews_snapshot:
        ev1_total_ratings += review.to_dict().get('rating', 0)
        ev1_num_reviews += 1
    ev1_average_score = ev1_total_ratings / ev1_num_reviews if ev1_num_reviews > 0 else 0
    ev2_total_ratings = 0
    ev2_num_reviews = 0
    for review in ev2_reviews_snapshot:
        ev2_total_ratings += review.to_dict().get('rating', 0)
        ev2_num_reviews += 1
    ev2_average_score = ev2_total_ratings / ev2_num_reviews if ev2_num_reviews > 0 else 0

    ev1_highest = ev1_average_score > ev2_average_score
    ev2_highest = ev2_average_score > ev1_average_score
    return templates.TemplateResponse("comparison.html", {"request": request, "ev1_data": ev1_data, "ev2_data": ev2_data,"ev1_average_score": ev1_average_score,
        "ev2_average_score": ev2_average_score})

@app.get("/update-data/{Ev_name}", response_class=HTMLResponse)
async def update_ev(request: Request,Ev_name: str):
    id_token = request.cookies.get("token")
    user_token = validateFirebaseToken(id_token)
    if not user_token:
        return RedirectResponse('/')
    docId=getDocID(Ev_name)
    collection_ref = firestore_db.collection('evlist')
    doc_ref = collection_ref.document(docId)
    ev_data = doc_ref.get()
    return templates.TemplateResponse("update2.html", {"request": request,'user_token': user_token, "Ev_info": ev_data })
@app.post("/update-result/{Ev_name}", response_class=RedirectResponse)
async def update_result(request: Request,Ev_name: str):
    form = await request.form()
    docId=getDocID(Ev_name)
    collection_ref = firestore_db.collection('evlist')
    collection_ref.document(docId).update({
       'Manufacturer': form['Manufacturere'],
        'Year': form['Year'],
        'Battery':form['Battery Size(Kwh)'],
        'WLTP':form['WLTP'],
        'cost':form['cost'],
        'Power':form['power']
    })
    return RedirectResponse('/', status_code=status.HTTP_302_FOUND)

@app.get("/delete-data/{Ev_name}", response_class=HTMLResponse)
async def delete_ev(request: Request,Ev_name: str):
    docId=getDocID(Ev_name)
    collection_ref = firestore_db.collection('evlist')
    doc_ref = collection_ref.document(docId)
    ev_data = doc_ref.get()        
    return templates.TemplateResponse("delete.html", {"request": request, "Ev_info": ev_data })

@app.post("/delete-result/{Ev_name}", response_class=RedirectResponse)
async def delete_result(request: Request,Ev_name: str):
    form = await request.form()
    
    docId=getDocID(Ev_name)
    collection_ref = firestore_db.collection('evlist')
    collection_ref.document(docId).delete()
    return RedirectResponse('/', status_code=status.HTTP_302_FOUND)

@app.post("/submit-review/{ev_id}", response_class=RedirectResponse)
async def submit_review(request: Request, ev_id: str):
    form = await request.form()
    review_text = form["review"]
    rating = int(form["rating"])  
    docID = getDocID(ev_id)
    save_review_to_firestore(docID, review_text, rating)
    return RedirectResponse('/', status_code=status.HTTP_302_FOUND)
@app.get("/ev-info-review/{ev_id}", response_class=HTMLResponse)
async def evreview_info(request: Request, ev_id: str):
    id_token = request.cookies.get("token")
    user_token = validateFirebaseToken(id_token)
    docID = getDocID(ev_id)
    collection_ref = firestore_db.collection('evlist')
    ev_data = collection_ref.document(docID).get()
    ev_ref = firestore_db.collection('ev_reviews').document(docID).collection('reviews')
    reviews_snapshot = ev_ref.order_by('timestamp', direction=firestore.Query.DESCENDING).limit(10).get()
    total_ratings = 0
    num_reviews = 0

    for review in reviews_snapshot:
        review_data = review.to_dict()
        total_ratings += review_data.get('rating', 0)
        num_reviews += 1
    average_score = total_ratings / num_reviews if num_reviews > 0 else 0
    reviews_data = [review.to_dict() for review in reviews_snapshot]

    return templates.TemplateResponse("info.html", {"request": request, "Ev_info": ev_data, "reviews": reviews_data, "average_score": average_score,'user_token' :user_token})
def save_review_to_firestore(ev_id, review_text, rating):
    ev_ref = firestore_db.collection('ev_reviews').document(ev_id)
    review_data = {
        'review_text': review_text,
        'rating': rating,
        'timestamp': datetime.now()
    }
    ev_ref.collection('reviews').add(review_data)
